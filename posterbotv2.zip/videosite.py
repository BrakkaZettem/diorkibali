from flask import Flask, render_template, send_file, redirect, url_for, request, flash
import os
import shutil
import subprocess
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Needed for flash messages

# Define the root directory where the video folders are located
ROOT_DIR = 'liloutput'
THUMBNAIL_DIR = 'static/thumbnails'

# Ensure thumbnail directory exists
os.makedirs(THUMBNAIL_DIR, exist_ok=True)

# Function to create a thumbnail from a video file
def create_thumbnail(video_path, thumbnail_path):
    if not os.path.exists(thumbnail_path):
        # Use ffmpeg to generate a thumbnail from the video
        command = [
            'ffmpeg', '-i', video_path,
            '-ss', '00:00:01.000',  # Take a frame at 1 second
            '-vframes', '1',        # Take only one frame
            thumbnail_path
        ]
        try:
            subprocess.run(command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        except subprocess.CalledProcessError as e:
            print(f"Error generating thumbnail: {e}")

@app.route('/videos')
def show_videos():
    # Get list of folders and individual video files in the root directory
    items = os.listdir(ROOT_DIR)
    folders = [item for item in items if os.path.isdir(os.path.join(ROOT_DIR, item))]
    videos = [item for item in items if os.path.isfile(os.path.join(ROOT_DIR, item)) and item.endswith(('.mp4', '.avi', '.mkv'))]

    # Create thumbnails for individual videos in the root directory
    video_thumbnails = {}
    for video in videos:
        video_path = os.path.join(ROOT_DIR, video)
        thumbnail_path = os.path.join(THUMBNAIL_DIR, f"{video}.jpg")
        create_thumbnail(video_path, thumbnail_path)
        # Normalize the path for URLs
        video_thumbnails[video] = thumbnail_path.replace(os.sep, '/')

    return render_template('videos.html', folders=folders, videos=video_thumbnails)

@app.route('/videos/<folder>')
def show_folder_videos(folder):
    folder_path = os.path.join(ROOT_DIR, folder)
    if not os.path.exists(folder_path):
        flash('Folder does not exist.', 'error')
        return redirect(url_for('show_videos'))

    videos = [f for f in os.listdir(folder_path) if f.endswith(('.mp4', '.avi', '.mkv'))]

    # Create thumbnails for videos in the folder
    video_thumbnails = {}
    for video in videos:
        video_path = os.path.join(folder_path, video)
        thumbnail_path = os.path.join(THUMBNAIL_DIR, f"{folder}_{video}.jpg")
        create_thumbnail(video_path, thumbnail_path)
        # Normalize the path for URLs
        video_thumbnails[video] = thumbnail_path.replace(os.sep, '/')

    return render_template('folder_videos.html', folder=folder, videos=video_thumbnails)

@app.route('/delete/<path:item>')
def delete_item(item):
    item_path = os.path.join(ROOT_DIR, item)
    if os.path.exists(item_path):
        if os.path.isdir(item_path):
            shutil.rmtree(item_path)
        else:
            os.remove(item_path)
        # Remove associated thumbnail if it exists
        thumbnail_path = os.path.join(THUMBNAIL_DIR, f"{item}.jpg")
        if os.path.exists(thumbnail_path):
            os.remove(thumbnail_path)
        flash(f'{item} has been deleted.', 'success')
    else:
        flash('Item does not exist.', 'error')
    return redirect(url_for('show_videos'))

@app.route('/download/<path:item>')
def download_item(item):
    item_path = os.path.join(ROOT_DIR, item)
    if os.path.exists(item_path):
        return send_file(item_path, as_attachment=True)
    else:
        flash('Item does not exist.', 'error')
        return redirect(url_for('show_videos'))

if __name__ == '__main__':
    app.run(debug=True)
