import requests
import threading
import time
import os
import random
from telethon import TelegramClient, sync
import shutil


timer = 0
tem_acc_amount = 50
poster_settings = []
last_post = [0] * tem_acc_amount
post_amount = [0] * tem_acc_amount
post_amount2 = [0] * tem_acc_amount
uploadedvideos = None

api_id = '20001746'
api_hash = 'ad25ff9fc57305256ab13ea27c611424'
username = "@davcuder"


def increment_global_variable():
    global timer
    while True:
        timer += 1
        time.sleep(1)

increment_thread = threading.Thread(target=increment_global_variable)
increment_thread.start()


def init_settings():
    print("initializing settings real quick")
    global poster_settings
    global last_post
    global post_amount
    global post_amount2

    url = "http://188.166.0.126/get_poster_info"
    response = requests.get(url)
    poster_settings = response.json()
    #print(f"new settings: {poster_settings}")


init_settings()

uploadedvideos = [[] for _ in range(len(poster_settings))]

print(uploadedvideos)

def post_video(account):
    global poster_settings
    global last_post
    global post_amount
    global uploadedvideos
    global timer
    global post_amount2
    
    last_post[account] = timer
    print("Posted!")
    
    current_directory = os.getcwd()
    lildirectory_path = f'{current_directory}/liloutput'
    
    files = os.listdir(lildirectory_path)
    if not files:
        return
    
    filename = random.choice(files)
    file_path = os.path.join(lildirectory_path, filename)
    
    attempts = 0
    max_attempts = 10
    while attempts < max_attempts:
        if file_path not in uploadedvideos[account]:
            break
        filename = random.choice(files)
        file_path = os.path.join(lildirectory_path, filename)
        attempts += 1
    
    if attempts == max_attempts:
        print("Could not find a new file to upload.")
        return
    
    uploadedvideos[account].append(file_path)
    
    if os.path.isfile(file_path):
        try:
            with TelegramClient(username, api_id, api_hash) as client:
                client.start()
                print(poster_settings[account]["channel"])
                client.send_file(poster_settings[account]["channel"], file_path)
                post_amount[account] += 1
                post_amount2[account] += 1
                if post_amount[account] > int(poster_settings[account]["message_freq"]):
                    post_amount[account] = 0
                    client.send_message(poster_settings[account]["channel"], poster_settings[account]["message"])
                if post_amount2[account] > int(poster_settings[account]["message2_freq"]):
                    post_amount2[account] = 0
                    client.send_message(poster_settings[account]["channel"], poster_settings[account]["message2"])
        except Exception as e:
            print(f"Error processing {filename} for account {account}: {e}")
    
    elif os.path.isdir(file_path):
        try:
            videos = []
            for dirpath, _, filenames in os.walk(file_path):
                for filename in filenames:
                    file_to_upload = os.path.join(dirpath, filename)
                    videos.append(file_to_upload)
            
            if videos:
                with TelegramClient(username, api_id, api_hash) as client:
                    client.start()
                    client.send_file(poster_settings[account]["channel"], videos)
                    post_amount[account] += 1
                    post_amount2[account] += 1
                    if post_amount[account] > int(poster_settings[account]["message_freq"]):
                        post_amount[account] = 0
                        client.send_message(poster_settings[account]["channel"], poster_settings[account]["message"])
                    if post_amount2[account] > int(poster_settings[account]["message2_freq"]):
                        post_amount2[account] = 0
                        client.send_message(poster_settings[account]["channel"], poster_settings[account]["message2"])
            print("Removing")
        except Exception as e:
            print(f"Error processing files in {file_path} for account {account}: {e}")



'''

def post_video(account):
    global poster_settings
    global last_post
    global post_amount
    global uploadedvideos
    global timer
    global post_amount2
    last_post[account] = timer
    print("Posted!")
    current_directory = os.getcwd()
    lildirectory_path = f'{current_directory}/liloutput'

    files = 0
    for filename in os.listdir(lildirectory_path):
        file_path = os.path.join(lildirectory_path, filename)
        files+=1
    if files == 0:
        return
    filename = os.listdir(lildirectory_path)[random.randint(0, files)-1]
    filename = os.listdir(lildirectory_path)[random.randint(0, files)-1]
    file_path = os.path.join(lildirectory_path, filename)
    while True:
        if file_path not in uploadedvideos[account]:
            break
        filename = os.listdir(lildirectory_path)[random.randint(0, files)-1]
        filename = os.listdir(lildirectory_path)[random.randint(0, files)-1]
        file_path = os.path.join(lildirectory_path, filename)

    uploadedvideos[account].append(file_path)

    if os.path.isfile(file_path):
        try:
            with TelegramClient(username, api_id, api_hash) as client:
                client.start()
                print(poster_settings[account]["channel"])
                client.send_file(poster_settings[account]["channel"], file_path)
                post_amount[account] +=1
                post_amount2[account] +=1
                if post_amount[account] > int(poster_settings[account]["message_freq"]):
                    post_amount[account] = 0
                    client.send_message(channel, poster_settings[account]["message"])
                if post_amount2[account] > int(poster_settings[account]["messafe2_freq"]):
                    post_amount2[account] = 0
                    client.send_message(channel, poster_settings[account]["message2"])
        except Exception as e:
            print(f"Error processing {filename}: {e}")


    elif os.path.isdir(file_path):  # If it's a directory, upload all files within it
        try:
            with TelegramClient(username, api_id, api_hash) as client:
                videos = []
                for dirpath, _, filenames in os.walk(file_path):
                    for filename in filenames:
                        file_to_upload = os.path.join(dirpath, filename)
                        videos.append(file_to_upload)

                if videos:
                    media = []
                    for video in videos:
                        media.append(video)
                    print(media)

                    # Send all videos in one message
                client.start()
                client.send_file(poster_settings[account]["channel"], media)
                post_amount[account] +=1
                post_amount2[account] +=1
                if post_amount[account] > int(poster_settings[account]["message_freq"]):
                    post_amount[account] = 0
                    client.send_message(poster_settings[account]["channel"], poster_settings[account]["message"])
                if post_amount2[account] > int(poster_settings[account]["messafe2_freq"]):
                    post_amount2[account] = 0
                    client.send_message(poster_settings[account]["channel"], poster_settings[account]["message2"])
            print("REMOVEING")
        except Exception as e:
            print(f"Error processing files in {file_path}: {e}")

'''

def delete_videos():
    global uploadedvideos
    # Flatten the array and create a dictionary to count occurrences
    from collections import Counter
    
    # Flatten the list of lists
    all_paths = [path for sublist in uploadedvideos for path in sublist]
    
    # Count the occurrences of each path
    path_counts = Counter(all_paths)
    
    # Find paths that are in every sublist
    common_paths = [path for path, count in path_counts.items() if count == len(uploadedvideos)]
    
    # Delete the common paths
    for path in common_paths:
        try:
            if os.path.isfile(path):
                os.remove(path)
                print(f"Deleted file: {path}")
            elif os.path.isdir(path):
                shutil.rmtree(path)
                print(f"Deleted directory: {path}")
            else:
                print(f"Path does not exist: {path}")
        except Exception as e:
            print(f"Error deleting {path}: {e}")


while True:
    for i in range(0, len(poster_settings)):
        if timer-last_post[i] > poster_settings[i]["post_freq"]:
            post_video(i)
            #delete_videos()
        time.sleep(900)
        init_settings()
        print("videos array:")
        print(uploadedvideos)
            